import sys
from fontTools.otlLib.optimize import main


if __name__ == "__main__":
    sys.exit(main())
